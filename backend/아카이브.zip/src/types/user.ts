export type User = {
  id: number
  username: string
  email: string
  password: string
  randomCode: string
  createdAt: Date
  updatedAt: Date
}
